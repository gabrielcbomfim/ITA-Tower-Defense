<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="mapa4" tilewidth="2624" tileheight="1472" tilecount="1" columns="1">
 <image source="../mapa4.png" width="2624" height="1472"/>
</tileset>
